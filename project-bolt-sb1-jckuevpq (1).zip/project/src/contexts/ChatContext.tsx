import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Message } from '../types';
import { getResponseForQuery } from '../utils/chatUtils';

// Create a context for chat state and functions
interface ChatContextType {
  messages: Message[];
  sendMessage: (content: string) => void;
  isProcessing: boolean;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

// Provider component
export const ChatContextProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  // Function to add a user message and get a response
  const sendMessage = (content: string) => {
    // Add user message
    const userMessage: Message = {
      role: 'user',
      content,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsProcessing(true);

    // Simulate response delay
    setTimeout(() => {
      const response = getResponseForQuery(content);
      
      // Add assistant response
      const assistantMessage: Message = {
        role: 'assistant',
        content: response.content,
        timestamp: new Date(),
        actionType: response.actionType,
      };

      setMessages((prev) => [...prev, assistantMessage]);
      setIsProcessing(false);
    }, 1000);
  };

  return (
    <ChatContext.Provider value={{ messages, sendMessage, isProcessing }}>
      {children}
    </ChatContext.Provider>
  );
};

// Custom hook to use the chat context
export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatContextProvider');
  }
  return context;
};