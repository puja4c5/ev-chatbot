interface ResponseData {
  content: string;
  actionType?: 'diagnose' | 'schedule' | 'locate' | 'info';
}

// This is a simplified mock response system
// In a real application, this would connect to a backend API or use a proper NLP system
export const getResponseForQuery = (query: string): ResponseData => {
  const lowerQuery = query.toLowerCase();
  
  // Vehicle not starting
  if (lowerQuery.includes('won\'t start') || lowerQuery.includes('not starting')) {
    return {
      content: "Let's check possible reasons. This could be due to a discharged battery, controller fault, or a safety lock. Try rebooting the vehicle system. Would you like me to run a remote health diagnostic?",
      actionType: 'diagnose'
    };
  }
  
  // Sudden stop
  if (lowerQuery.includes('stopped while driving') || lowerQuery.includes('stop suddenly')) {
    return {
      content: "Please stay safe and turn on hazard lights. This might be a battery shutdown, thermal overload, or inverter fault. Shall I call roadside help or connect you to the nearest service partner?",
      actionType: 'locate'
    };
  }
  
  // Battery health
  if (lowerQuery.includes('battery') && (lowerQuery.includes('health') || lowerQuery.includes('condition'))) {
    return {
      content: "Your battery's health is currently at 91%, which is in great shape. Charging and discharging cycles are within normal range. Would you like tips to maintain long battery life?",
      actionType: 'info'
    };
  }
  
  // Maintenance schedule
  if (lowerQuery.includes('next service') || lowerQuery.includes('maintenance schedule')) {
    return {
      content: "Your EV is due for a periodic check-up in 850 km or 15 days. Want me to book a service slot or send a reminder?",
      actionType: 'schedule'
    };
  }
  
  // Noise while braking
  if ((lowerQuery.includes('noise') || lowerQuery.includes('sound')) && lowerQuery.includes('brak')) {
    return {
      content: "This could mean your brake pads are worn out or there's debris in the brake system. Want me to run a brake check or guide you through a quick inspection?",
      actionType: 'diagnose'
    };
  }
  
  // Dashboard warnings
  if (lowerQuery.includes('warning') || lowerQuery.includes('symbol') || lowerQuery.includes('alert')) {
    return {
      content: "If you can describe or upload the symbol, I'll identify it for you. Warnings may relate to tire pressure, motor faults, or high temperature. Let me help decode it.",
      actionType: 'info'
    };
  }
  
  // Regenerative braking explanation
  if (lowerQuery.includes('regenerative') || (lowerQuery.includes('regen') && lowerQuery.includes('brak'))) {
    return {
      content: "Regenerative braking captures energy during deceleration and feeds it back to the battery, increasing efficiency. Want a short animation or voice explanation on how it works?",
      actionType: 'info'
    };
  }
  
  // Cost of repairs
  if (lowerQuery.includes('cost') && (lowerQuery.includes('repair') || lowerQuery.includes('replace'))) {
    return {
      content: "Battery module replacement can cost ₹25,000–₹40,000, and motor repairs around ₹10,000. Would you like me to compare prices from nearby authorized service centers?",
      actionType: 'locate'
    };
  }
  
  // Sensor check
  if (lowerQuery.includes('check') && (lowerQuery.includes('sensor') || lowerQuery.includes('diagnostic'))) {
    return {
      content: "Running sensor scan… Motor temperature is normal, battery voltage stable, tire pressure slightly low on rear-left. Would you like repair suggestions or a PDF report?",
      actionType: 'diagnose'
    };
  }
  
  // Replaceable parts
  if (lowerQuery.includes('replaceable parts') || lowerQuery.includes('worn-out') || lowerQuery.includes('repair parts')) {
    return {
      content: "Brake pads show 75% wear, cabin filter needs cleaning, and coolant levels are low. Want links to replacement parts or book a repair slot?",
      actionType: 'schedule'
    };
  }
  
  // Charging station finder
  if (lowerQuery.includes('charging station') || lowerQuery.includes('charger nearby')) {
    return {
      content: "I've found 3 charging stations near you:\n1. Tesla Supercharger (2.3 km) - 250kW DC, 8 stalls\n2. ChargePoint (4.1 km) - 50kW DC, 4 stalls\n3. Electrify America (5.8 km) - 150kW DC, 6 stalls\n\nWould you like directions to any of these?",
      actionType: 'locate'
    };
  }
  
  // Default response for unknown queries
  return {
    content: "I'm here to help with your electric vehicle needs. You can ask me about diagnostics, maintenance schedules, charging stations, battery health, or troubleshooting specific issues. How can I assist you today?",
    actionType: 'info'
  };
};