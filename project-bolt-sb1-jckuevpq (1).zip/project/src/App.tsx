import React from 'react';
import { ChatContextProvider } from './contexts/ChatContext';
import Layout from './components/Layout';
import ChatInterface from './components/ChatInterface';

function App() {
  return (
    <ChatContextProvider>
      <Layout>
        <ChatInterface />
      </Layout>
    </ChatContextProvider>
  );
}

export default App;