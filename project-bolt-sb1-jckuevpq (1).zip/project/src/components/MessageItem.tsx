import React from 'react';
import { Battery, Zap, Calendar, Info, AlertTriangle, CheckCircle, AlertCircle } from 'lucide-react';
import { Message } from '../types';

interface MessageItemProps {
  message: Message;
}

const MessageItem: React.FC<MessageItemProps> = ({ message }) => {
  const isUser = message.role === 'user';

  const getMessageIcon = () => {
    if (isUser) return null;

    // Dynamically choose an icon based on the message content
    // This is a simplified version - in a real app, you would use NLP to analyze the message
    if (message.content.toLowerCase().includes('battery')) {
      return <Battery className="h-5 w-5 text-primary-500" />;
    } else if (message.content.toLowerCase().includes('service') || message.content.toLowerCase().includes('maintenance')) {
      return <Calendar className="h-5 w-5 text-primary-500" />;
    } else if (message.content.toLowerCase().includes('warning') || message.content.toLowerCase().includes('alert')) {
      return <AlertTriangle className="h-5 w-5 text-warning-500" />;
    } else if (message.content.toLowerCase().includes('check') || message.content.toLowerCase().includes('diagnostic')) {
      return <CheckCircle className="h-5 w-5 text-success-500" />;
    } else if (message.content.toLowerCase().includes('error') || message.content.toLowerCase().includes('fault')) {
      return <AlertCircle className="h-5 w-5 text-error-500" />;
    } else {
      return <Info className="h-5 w-5 text-primary-500" />;
    }
  };

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`${isUser ? 'bg-primary-100 text-neutral-800' : 'bg-white border border-neutral-200'} max-w-[85%] md:max-w-[70%] rounded-lg px-4 py-3 shadow-sm`}>
        {!isUser && (
          <div className="flex items-center mb-1.5">
            <div className="bg-neutral-100 rounded-full p-1.5 mr-2">
              {getMessageIcon()}
            </div>
            <span className="font-medium text-primary-800">EV Buddy</span>
          </div>
        )}
        <div>
          {message.content.split('\n').map((line, i) => (
            <p key={i} className={`${i > 0 ? 'mt-2' : ''}`}>
              {line}
            </p>
          ))}
        </div>
        {!isUser && message.actionType && (
          <div className="mt-3 pt-3 border-t border-neutral-200">
            <ActionButton actionType={message.actionType} />
          </div>
        )}
      </div>
    </div>
  );
};

interface ActionButtonProps {
  actionType: 'diagnose' | 'schedule' | 'locate' | 'info' | string;
}

const ActionButton: React.FC<ActionButtonProps> = ({ actionType }) => {
  let buttonText = '';
  let Icon = Info;
  let bgColor = 'bg-primary-500';
  let hoverColor = 'hover:bg-primary-600';

  switch (actionType) {
    case 'diagnose':
      buttonText = 'Run Diagnostic';
      Icon = Zap;
      break;
    case 'schedule':
      buttonText = 'Schedule Service';
      Icon = Calendar;
      bgColor = 'bg-success-500';
      hoverColor = 'hover:bg-success-600';
      break;
    case 'locate':
      buttonText = 'Find Service Centers';
      bgColor = 'bg-warning-500';
      hoverColor = 'hover:bg-warning-600';
      break;
    case 'info':
    default:
      buttonText = 'Learn More';
      break;
  }

  return (
    <button className={`${bgColor} ${hoverColor} text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center transition-colors`}>
      <Icon className="h-4 w-4 mr-2" />
      {buttonText}
    </button>
  );
};

export default MessageItem;