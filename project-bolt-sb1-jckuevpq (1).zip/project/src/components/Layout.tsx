import React, { ReactNode, useState } from 'react';
import { Menu, X, Battery, Calendar, Settings, HelpCircle, FileText, Home } from 'lucide-react';

interface LayoutProps {
  children: ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-neutral-200 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 rounded-full hover:bg-neutral-100 lg:hidden"
            >
              <Menu size={24} className="text-neutral-700" />
            </button>
            <div className="flex items-center">
              <Battery className="h-7 w-7 text-primary-500 mr-2" />
              <h1 className="text-xl font-bold text-neutral-800">EV Buddy</h1>
            </div>
          </div>
          <div>
            <button className="py-1.5 px-3 rounded-full bg-primary-500 text-white font-medium hover:bg-primary-600 transition-colors text-sm">
              Connect Vehicle
            </button>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar for navigation */}
        <aside 
          className={`${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          } fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-neutral-200 shadow-lg transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:z-0`}
        >
          <div className="p-4 flex justify-between items-center border-b border-neutral-200 lg:hidden">
            <div className="flex items-center">
              <Battery className="h-6 w-6 text-primary-500 mr-2" />
              <h2 className="font-semibold text-neutral-800">EV Buddy</h2>
            </div>
            <button 
              onClick={() => setSidebarOpen(false)}
              className="p-1.5 rounded-full hover:bg-neutral-100"
            >
              <X size={20} className="text-neutral-700" />
            </button>
          </div>
          <nav className="p-4">
            <ul className="space-y-1">
              <li>
                <a href="#" className="flex items-center px-3 py-2.5 rounded-lg text-neutral-700 hover:bg-neutral-100 font-medium">
                  <Home className="h-5 w-5 mr-3 text-neutral-500" />
                  Dashboard
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center px-3 py-2.5 rounded-lg bg-primary-50 text-primary-600 font-medium">
                  <HelpCircle className="h-5 w-5 mr-3 text-primary-500" />
                  EV Buddy Chat
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center px-3 py-2.5 rounded-lg text-neutral-700 hover:bg-neutral-100 font-medium">
                  <Battery className="h-5 w-5 mr-3 text-neutral-500" />
                  Vehicle Diagnostics
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center px-3 py-2.5 rounded-lg text-neutral-700 hover:bg-neutral-100 font-medium">
                  <Calendar className="h-5 w-5 mr-3 text-neutral-500" />
                  Maintenance Schedule
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center px-3 py-2.5 rounded-lg text-neutral-700 hover:bg-neutral-100 font-medium">
                  <FileText className="h-5 w-5 mr-3 text-neutral-500" />
                  Service Logs
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center px-3 py-2.5 rounded-lg text-neutral-700 hover:bg-neutral-100 font-medium">
                  <Settings className="h-5 w-5 mr-3 text-neutral-500" />
                  Settings
                </a>
              </li>
            </ul>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto bg-neutral-50">
          {sidebarOpen && (
            <div 
              className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
              onClick={() => setSidebarOpen(false)}
            ></div>
          )}
          <div className="container mx-auto px-4 py-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;