import React from 'react';
import { useChat } from '../contexts/ChatContext';
import { Battery, Car, Wrench, Calendar, MapPin, AlertCircle } from 'lucide-react';
import MessageItem from './MessageItem';

const MessageList: React.FC = () => {
  const { messages } = useChat();

  // If no messages, show welcome prompt
  if (messages.length === 0) {
    return (
      <div className="py-10 px-4">
        <div className="text-center mb-6">
          <div className="inline-block p-3 bg-primary-50 rounded-full mb-3">
            <Battery className="h-8 w-8 text-primary-500" />
          </div>
          <h3 className="text-lg font-semibold text-neutral-800">Welcome to EV Buddy</h3>
          <p className="text-neutral-600 max-w-md mx-auto mt-1">
            Your personal electric vehicle assistant. Ask me anything about your EV!
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-w-2xl mx-auto">
          <SuggestionCard 
            icon={<Car className="h-5 w-5 text-primary-500" />}
            title="Diagnostics"
            prompt="Why won't my car start?"
          />
          <SuggestionCard 
            icon={<Battery className="h-5 w-5 text-primary-500" />}
            title="Battery Health"
            prompt="What's my battery condition?"
          />
          <SuggestionCard 
            icon={<Calendar className="h-5 w-5 text-primary-500" />}
            title="Maintenance"
            prompt="When is my next service?"
          />
          <SuggestionCard 
            icon={<Wrench className="h-5 w-5 text-primary-500" />}
            title="Repairs"
            prompt="I hear a noise while braking"
          />
          <SuggestionCard 
            icon={<AlertCircle className="h-5 w-5 text-primary-500" />}
            title="Warnings"
            prompt="What does this dashboard symbol mean?"
          />
          <SuggestionCard 
            icon={<MapPin className="h-5 w-5 text-primary-500" />}
            title="Charging"
            prompt="Find me a charging station nearby"
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 py-2">
      {messages.map((message, index) => (
        <MessageItem key={index} message={message} />
      ))}
    </div>
  );
};

interface SuggestionCardProps {
  icon: React.ReactNode;
  title: string;
  prompt: string;
}

const SuggestionCard: React.FC<SuggestionCardProps> = ({ icon, title, prompt }) => {
  const { sendMessage } = useChat();

  return (
    <button 
      className="p-3 bg-white border border-neutral-200 rounded-lg hover:bg-neutral-50 transition-colors text-left flex items-start shadow-sm hover:shadow"
      onClick={() => sendMessage(prompt)}
    >
      <div className="mt-0.5 mr-3">{icon}</div>
      <div>
        <h4 className="font-medium text-neutral-800">{title}</h4>
        <p className="text-sm text-neutral-600 mt-0.5">{prompt}</p>
      </div>
    </button>
  );
};

export default MessageList;