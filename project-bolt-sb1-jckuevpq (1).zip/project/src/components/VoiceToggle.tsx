import React, { useState, useEffect } from 'react';
import { useChat } from '../contexts/ChatContext';
import { Mic, MicOff } from 'lucide-react';

// Voice recognition in browser environment
const VoiceToggle: React.FC = () => {
  const [isListening, setIsListening] = useState(false);
  const [hasVoiceSupport, setHasVoiceSupport] = useState(false);
  const { sendMessage } = useChat();

  // Check if browser supports speech recognition
  useEffect(() => {
    const hasSpeechRecognition = 
      'SpeechRecognition' in window || 
      'webkitSpeechRecognition' in window;
    
    setHasVoiceSupport(hasSpeechRecognition);
  }, []);

  const toggleListening = () => {
    if (!hasVoiceSupport) return;

    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const startListening = () => {
    setIsListening(true);
    
    // In a real implementation, we would use the Web Speech API
    // This is a simplified mock version for demo purposes
    setTimeout(() => {
      // Simulating speech recognition ending after 5 seconds
      sendMessage("What's my battery health?");
      setIsListening(false);
    }, 5000);
  };

  const stopListening = () => {
    setIsListening(false);
  };

  if (!hasVoiceSupport) {
    return null;
  }

  return (
    <button
      onClick={toggleListening}
      className={`p-3 rounded-lg border ${
        isListening
          ? 'bg-primary-500 text-white border-primary-500'
          : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
      } transition-colors relative`}
      aria-label={isListening ? 'Stop listening' : 'Start voice input'}
    >
      {isListening ? (
        <>
          <MicOff size={20} className="relative z-10" />
          <VoiceWaves />
        </>
      ) : (
        <Mic size={20} />
      )}
    </button>
  );
};

const VoiceWaves = () => {
  return (
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((i) => (
          <div
            key={i}
            className={`h-4 w-0.5 bg-white opacity-75 rounded-full animate-wave`}
            style={{
              animationDelay: `${i * 0.1}s`,
              height: `${i * 3 + 7}px`,
            }}
          ></div>
        ))}
      </div>
    </div>
  );
};

export default VoiceToggle;