import React, { useState } from 'react';
import { useChat } from '../contexts/ChatContext';
import { Send } from 'lucide-react';

const ChatInput: React.FC = () => {
  const [input, setInput] = useState('');
  const { sendMessage, isProcessing } = useChat();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isProcessing) {
      sendMessage(input);
      setInput('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex-1">
      <div className="relative">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about your EV..."
          className="w-full py-3 px-4 pr-12 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          disabled={isProcessing}
        />
        <button
          type="submit"
          disabled={!input.trim() || isProcessing}
          className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full ${
            input.trim() && !isProcessing
              ? 'bg-primary-500 text-white hover:bg-primary-600'
              : 'bg-neutral-200 text-neutral-500 cursor-not-allowed'
          } transition-colors`}
        >
          <Send size={18} />
        </button>
      </div>
    </form>
  );
};

export default ChatInput;