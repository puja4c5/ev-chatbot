import React, { useRef, useEffect } from 'react';
import { useChat } from '../contexts/ChatContext';
import ChatInput from './ChatInput';
import MessageList from './MessageList';
import VoiceToggle from './VoiceToggle';

const ChatInterface: React.FC = () => {
  const { messages } = useChat();
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-w-4xl mx-auto">
      <div className="mb-4">
        <h2 className="text-2xl font-bold text-neutral-800">EV Buddy Assistant</h2>
        <p className="text-neutral-600">Ask me anything about your electric vehicle</p>
      </div>
      
      <div className="flex-1 bg-white rounded-xl shadow-sm border border-neutral-200 flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-neutral-300 scrollbar-track-transparent">
          <MessageList />
          <div ref={chatEndRef} />
        </div>
        
        <div className="border-t border-neutral-200 p-3">
          <div className="flex items-center gap-2">
            <ChatInput />
            <VoiceToggle />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;